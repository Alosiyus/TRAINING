x={
"com": [
{"sno":"0","cname": "WIPRO", "locate": "Banglore"},
{"sno":"1","cname": "TCS", "locate": "Kolkatta"},
{"sno":"2","cname": "DELL", "locate": "Chennai"},
{"sno":"3","cname": "OFS", "locate": "Delhi"},
{"sno":"4","cname": "IBM", "locate": "Chennai"},
{"sno":"5","cname": "Google", "locate": "Madurai"}
  ]
  }
  sno=[];
cname=[];
locate=[];


		  
		  
function createcompanytable(){
      collection=[sno,cname,locate];
	  for(var i=0;i<(x.com).length;i++)
        {

          sno[i]=x.com[i].sno;
          cname[i]=x.com[i].cname;
          locate[i]=x.com[i].locate;
          }
		  
		  
		  for(var i=0;i<(x.com).length;i++){
              var row=document.getElementById("table").insertRow();
				for(var j = 0 ; j <1 ; j++){
				row.insertCell().innerHTML=(x.com[i].sno);
				row.insertCell().innerHTML=(x.com[i].cname);
				row.insertCell().innerHTML=(x.com[i].locate);
				var b=(x.com[i].sno);
				row.insertCell().innerHTML=("<button type='button' class='btn btn-sm btn-success' >EDIT</button> <button type='button'  class='btn btn-sm btn-danger' >DELETE</button>");

			}

			}
}s
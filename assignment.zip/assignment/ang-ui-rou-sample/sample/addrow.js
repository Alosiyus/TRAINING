
var zapp=angular.module('myApp1');
zapp.controller("addrowcontroller",['$scope','$state',function($scope,$state){
    $scope.addRecord=function(){
	
	if ($scope.id != undefined &&$scope.name != undefined && $scope.city != undefined) {
                var mov1 = [];
				mov1.id = $scope.id;
                mov1.name = $scope.name;
                mov1.city = $scope.city;
                    
                $scope.details.push(mov1);

                // CLEAR TEXTBOX.
				$scope.id = null;
                $scope.name = null;
                $scope.city = null;
	}
	
	};
	$scope.cancel=function(){
		
		$state.go("company");
		
		
	};

}]);

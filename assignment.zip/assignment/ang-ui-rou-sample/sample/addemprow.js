
var zzapp=angular.module('myApp1');
zzapp.controller("addemprowcontroller",['$scope','$state',function($scope,$state){
    $scope.addRecord=function(){
	
	if ($scope.Empid != undefined &&$scope.Empname != undefined && $scope.Empplace != undefined) {
                var mov1 = [];
				mov1.Empid = $scope.Empid;
                mov1.Empname = $scope.Empname;
                mov1.Empplace = $scope.Empplace;
                    
                $scope.empdetails.push(mov1);

                // CLEAR TEXTBOX.
				$scope.Empid = null;
                $scope.Empname = null;
                $scope.Empplace = null;
	}
	
	};
	$scope.cancel=function(){
		
		$state.go("employee");
		
		
	};

}]);

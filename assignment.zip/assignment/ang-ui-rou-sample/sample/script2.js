var eeapp = angular.module('myApp2', []);
eeapp.controller('employeeController', ['$scope','$state', function($scope,$state){
 $scope.empdetails=[
		   {
			   "Empid":21,
			   "Empname":"Alosiyus",
			   "Empplace":"tamilnad"
		   },
            {
			   "Empid":36,
			   "Empname":"dhoni",
			   "Empplace":"Ranchi"
		   },
		     {
			   "Empid":42,
			   "Empname":"Sachin",
			   "Empplace":"Mumbai"
		   },
		   {
			   "Empid":42,
			   "Empname":"Ganguly",
			   "Empplace":"Bengal"
		   },
		   {
			   "Empid":49,
			   "Empname":"vikram",
			   "Empplace":"banglore"
		   }

		    ];
  $scope.editingData = {};
			 
			  for (var i = 0, length = $scope.empdetails.length; i < length; i++) {
      $scope.editingData[$scope.empdetails[i].Empid] = false;
    }


    $scope.modify = function(details){
        $scope.editingData[details.Empid] = true;
    };


    $scope.update = function(details){
        $scope.editingData[details.Empid] = false;
    };

	
	
	$scope.delete_table = function (details) {
				// alert("do you want to delete this row");
                var index = $scope.Empdetails.indexOf(details);
				if(window.confirm("Are you sure you want to delete this row!!")){
                $scope.empdetails.splice(index, 1);
				}
            };
			
			
			 $scope.addRow = function () {
           /*  if ($scope.name != undefined && $scope.city != undefined) {
                var movie = [];
                movie.name = $scope.name;
                movie.city = $scope.city;

                $scope.details.push(movie);

                // CLEAR TEXTBOX.
                $scope.name = null;
                $scope.city = null; */
				$state.go("employee.newrow");
            
        };
			  
}]);
function mydemo() {
    var x = document.forms["myForm"]["fname"].value;
    var y = document.forms["myForm"]["mailid"].value;
    var z = document.forms["myForm"]["birthplace"].value;
    var a = document.forms["myForm"]["pno"].value;
    var b = document.forms["myForm"]["age"].value;
   	
    if (x == "" && y == "" && z == "" && a == "" && b == "") {
        alert("please fill all fields");
        return false;
    }

   else if (y != "") {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if (re.test(y) == false) {
            alert("Enter in Email Format");
        }
    }
  else  if (a != "") {
        var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
        if (phoneno.test(a) == false) {
            alert("Enter Correct Phone number");
        }
    }
  else  if (isNaN(b) || b < 1 || b > 100) {
        alert("The age must be a number between 1 and 100");
        return false;
    } else {
        document.write("success");
}

}







/*
function nameval() {
    var x = document.forms["myForm"]["fname"].value;
    if (x == "") {
        alert("Name must be filled out");
        return false;
    }
}


function emailval() {
  var y = document.forms["myForm"]["mailid"].value;
    if (y == "") {
        alert("emailid must be filled out");
        return false;
    }
if (isNaN(b)||b<1||b>100)
{
    alert("The age must be a number between 1 and 100");
    return false;
}
document.write("success");
}



function pobval() {
 var z = document.forms["myForm"]["birthplace"].value;
    if (z == "") {
        alert("Place of birth must be filled out");
        return false;
}
}

function phoneval() {

 var a = document.forms["myForm"]["pno"].value;
    if (a == "") {
        alert("mobileno must be filled out");
	
        return false;
}

if(phone!==""){
var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
if(phoneno.test(phone)== false){
  alert("Enter Correct Phone number");
}
}
}
function ageval() {
 var b = document.forms["myForm"]["age"].value;
    if (b == "") {
        alert("age must be filled out");
        return false;
}
if (isNaN(age)||age<1||age>100)
{
    alert("The age must be a number between 1 and 100");
    return false;
}


}

document.write("success");
}*/



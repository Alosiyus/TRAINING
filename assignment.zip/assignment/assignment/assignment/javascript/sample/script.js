var2=10;
var3=30;
function demo()
{
//ADDING var AS 20 IN DEMO FUNCTION
var var2=20;
alert("Hello World");
document.write("<br>");
document.write("Value from DEMO FUNCTION  : ");
document.write(var2);
return var2;
}
demo();
document.write("<br>");
document.write("<br>");
document.write("<br>");
document.write("ENTER VALUE 1   :");
document.write("<input type='text' id='txt1' placeholder='ENTER NUMBER 1'>");
document.write("<br>");

var chk1 = document.getElementById("txt1").value;
//TO CHECK THE DATA1 IS NUMBER OR NOT

if(isNaN(chk1) == true )
{
document.write("<br>");
document.write("VALUE1 IS NOT A NUMBER");

}
if(isNaN(chk1) == false)
{
document.write("<br>");
document.write("VALUE1 IS A NUMBER");

}
document.write("<br>");
document.write("ENTER VALUE 2   :");
document.write("<input type='text' id='txt2' placeholder='ENTER NUMBER 2'>");
document.write("<br>");

//TO CHECK THE DATA2 IS NUMBER OR NOT
var chk2 = document.getElementById("txt2").value;
if(isNaN(chk2) == true )
{
document.write("<br>");
document.write("VALUE2 IS NOT A NUMBER");

}
if(isNaN(chk2) == false)
{
document.write("<br>");
document.write("VALUE2 IS A NUMBER");

}
document.write("<br>");
document.write("<br>");
document.write("<br>");
document.write("<b>AFTER ENTERING DATA RELOAD THE PAGE</b>");
document.write("<br>");

//TO GET EVAL OF TWO NUMBERS
document.write("<br>");
document.write("<br>");
document.write("<button onclick='document.write(eval(chk1+chk2))'> click here to see answer of EVAL </button>");
document.write("<button onclick='alert(eval(chk1+chk2))'> click here to see answer of EVAL in alert Box </button>");
//document.write("Value of EVAL of BOX1 and BOX2 : ");
//document.write(eval(chk1+chk2));



document.write("<br>");
document.write("<br>");
document.write("<br>");
document.write("<br>");
document.write("<br>");
document.write("<br>");


function demo()
{
   var num2=20;
   var num3=eval('num1+num2');
   alert("total="+num3);
   alert( isNaN(num3));
}
demo();


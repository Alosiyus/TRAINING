function demo()
{
  alert("hello world");
}
demo();


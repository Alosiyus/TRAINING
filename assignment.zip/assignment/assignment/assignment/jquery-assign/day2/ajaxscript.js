$(document).ready(function() {
    $('#button1').click(function()
    {
        $.ajax({
        type: 'GET',
        url: 'https://jsonplaceholder.typicode.com/posts/',
        datatype: 'JSON',
        
            success: function(datareceive) {
               // $('#scrolltable').attr("class","scroll")                
                var mytablejs=document.getElementById("mytable");
                var row;
                var n=(datareceive).length;
                for(var i=0;i<n;i++){
                  
                    row = mytablejs.insertRow();
                    var Id = row.insertCell();
                    var title = row.insertCell();
                    var body = row.insertCell();
                    Id.innerHTML=datareceive[i].id;
                    title.innerHTML=datareceive[i].title;
                    body.innerHTML=datareceive[i].body;
                    
                }
            },
            error: function(error) {
                alert("error");
            }
        } );    
    });
});
var routingExample = angular.module('FunnyAnt.Examples.Routing', ['ngRoute']);

routingExample.config(function ($routeProvider) {
    $routeProvider
    
    .when('/home', {
        templateUrl: 'templates/home.html'
    })
    
    .when('/contactUs', {
        templateUrl: 'templates/contactus.html'
    })
    
    .when('/about', {
        templateUrl: 'templates/about.html'
    })
    
    .otherwise({
        redirectTo: 'templates/home.html'
    });
    
});
